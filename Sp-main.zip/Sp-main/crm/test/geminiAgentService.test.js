'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { askGeminiAgent, buildCrmContext, parseAgentResponse } = require('../src/services/geminiAgentService');

test('buildCrmContext exposes bounded CRM fields and totals', () => {
  const context = buildCrmContext({ read: () => ({
    Leads: [{ LeadID: 'L1', ClientName: 'A', SecretNote: 'hidden' }],
    Requirements: [], Inventory: [], BuilderProjects: [], FollowUps: []
  }) });
  assert.equal(context.totals.leads, 1);
  assert.deepEqual(context.leads[0], { LeadID: 'L1', ClientName: 'A' });
  assert.equal(context.leads[0].SecretNote, undefined);
});

test('parseAgentResponse accepts JSON fences and limits suggested actions', () => {
  const result = parseAgentResponse('```json\n{"message":"Namaste","suggestedActions":["one","two","three","four","five","six"]}\n```');
  assert.equal(result.message, 'Namaste');
  assert.equal(result.suggestedActions.length, 5);
});

test('askGeminiAgent requires an API key', async () => {
  const originalKey = process.env.GEMINI_API_KEY;
  delete process.env.GEMINI_API_KEY;
  await assert.rejects(
    () => askGeminiAgent({ repository: { read: () => ({}) }, message: 'Show my leads' }),
    /GEMINI_API_KEY is not configured/
  );
  if (originalKey === undefined) delete process.env.GEMINI_API_KEY;
  else process.env.GEMINI_API_KEY = originalKey;
});